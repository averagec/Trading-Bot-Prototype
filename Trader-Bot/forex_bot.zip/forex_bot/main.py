"""
Forex Bot — Main Orchestrator
Runs the full agent loop every cycle:
  1. Connect MT5
  2. Check news window
  3. Fetch OHLCV data
  4. Run strategy confluence
  5. LLM decision
  6. Execute trade (if signal)
  7. Log to Excel
"""

import logging
import time
import sys
from datetime import datetime, timezone
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import PAIRS, PRIMARY_TF, CONFIRM_TF, BIAS_TF, RISK, MIN_SCORE_TO_TRADE, EXCEL
from mt5_connector import connector
from strategies.smc_strategies import run_confluence
from agents.news_agent import news_agent
from agents.llm_agent import llm_agent
from utils.excel_manager import excel_manager

# ── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("forex_bot.log"),
    ]
)
logger = logging.getLogger("orchestrator")


class ForexBot:

    def __init__(self):
        self.running       = False
        self.cycle_count   = 0
        self.trades_today  = 0

    # ── Startup ────────────────────────────────────────────────────────────────

    def startup(self):
        """Initialise everything."""
        logger.info("=" * 60)
        logger.info("  FOREX BOT STARTING UP")
        logger.info("=" * 60)

        # Create or verify Excel workbook
        if not Path(EXCEL["path"]).exists():
            logger.info("Creating Excel dashboard...")
            excel_manager.create_workbook()
        else:
            logger.info(f"Using existing workbook: {EXCEL['path']}")

        # Connect to MT5
        connected = connector.connect()
        if connected:
            logger.info("MT5 connection established.")
        else:
            logger.warning("MT5 not connected — running in simulation mode.")

        # Update dashboard
        account = connector.get_account_info()
        excel_manager.update_dashboard(account or {}, bot_status="STARTING")

        logger.info("Bot initialised. Starting main loop...")

    # ── Main Loop ──────────────────────────────────────────────────────────────

    def run(self, interval_seconds: int = 900):  # 15 minutes
        """Main loop — runs every interval_seconds."""
        self.startup()
        self.running = True

        while self.running:
            try:
                self.cycle_count += 1
                logger.info(f"\n{'─' * 50}")
                logger.info(f"  CYCLE #{self.cycle_count} | {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
                logger.info(f"{'─' * 50}")

                self._run_cycle()

            except KeyboardInterrupt:
                logger.info("Keyboard interrupt — shutting down.")
                self.shutdown()
                break
            except Exception as e:
                logger.error(f"Cycle error: {e}", exc_info=True)

            logger.info(f"Sleeping {interval_seconds}s until next cycle...")
            time.sleep(interval_seconds)

    def _run_cycle(self):
        """Single analysis + execution cycle across all pairs."""

        # 1. Account status
        account = connector.get_account_info()
        positions = connector.get_open_positions()

        if account:
            logger.info(f"Account | Balance: {account['balance']} | Equity: {account['equity']} | Positions: {len(positions)}")
            excel_manager.update_dashboard(account, bot_status="RUNNING")

            # Daily loss guard
            daily_pnl_pct = (account.get("profit", 0) / account["balance"]) * 100
            if daily_pnl_pct <= -RISK["max_daily_loss_pct"]:
                logger.warning(f"Daily loss limit hit ({daily_pnl_pct:.2f}%) — skipping all trades.")
                excel_manager.update_dashboard(account, bot_status="DAILY LIMIT HIT")
                return

        # 2. Max open positions check
        if len(positions) >= RISK["max_open_trades"]:
            logger.info(f"Max positions ({RISK['max_open_trades']}) reached — skipping new signals.")
            return

        # 3. Fetch and update news
        upcoming_news = news_agent.get_upcoming_events(hours_ahead=4)
        if upcoming_news:
            excel_manager.write_news(upcoming_news)
            logger.info(f"Found {len(upcoming_news)} upcoming high-impact news events.")

        # 4. Analyse each pair
        for symbol in PAIRS:
            try:
                self._analyse_pair(symbol, account or {}, positions)
            except Exception as e:
                logger.error(f"Error analysing {symbol}: {e}", exc_info=True)

    def _analyse_pair(self, symbol: str, account: dict, positions: list):
        """Full analysis pipeline for a single symbol."""
        logger.info(f"\nAnalysing {symbol}...")

        # Check news window first
        news_summary = news_agent.summary(symbol)
        news_blocked = news_summary["news_window"]["is_blocked"]

        if news_blocked:
            logger.info(f"{symbol}: BLOCKED — {news_summary['news_window']['reason']}")

        # Fetch OHLCV data across timeframes
        df_entry   = connector.get_ohlcv(symbol, PRIMARY_TF)
        df_confirm = connector.get_ohlcv(symbol, CONFIRM_TF)
        df_bias    = connector.get_ohlcv(symbol, BIAS_TF)

        if df_entry is None or df_confirm is None or df_bias is None:
            logger.warning(f"{symbol}: Failed to fetch OHLCV data")
            return

        # Run strategy confluence
        confluence = run_confluence(df_entry, df_confirm, df_bias)
        confluence["symbol"] = symbol

        logger.info(
            f"{symbol} | Direction: {confluence['direction']} | "
            f"Probability: {confluence['probability']}% | "
            f"News: {'BLOCKED' if news_blocked else 'CLEAR'}"
        )

        # LLM decision
        llm_decision = llm_agent.make_trade_decision(
            symbol=symbol,
            confluence=confluence,
            news_summary=news_summary,
            account_info=account,
            open_positions=positions,
        )

        logger.info(
            f"{symbol} | LLM: {llm_decision.get('decision')} | "
            f"Confidence: {llm_decision.get('confidence')}% | "
            f"{llm_decision.get('reasoning', '')[:80]}"
        )

        # Write signal to Excel
        excel_manager.write_signal({
            **confluence,
            "news_blocked":    news_blocked,
            "llm_decision":    llm_decision.get("decision"),
            "llm_confidence":  llm_decision.get("confidence"),
            "llm_reasoning":   llm_decision.get("reasoning"),
        })

        # Execute if conditions met
        should_trade = (
            not news_blocked
            and confluence["probability"] >= MIN_SCORE_TO_TRADE
            and llm_decision.get("decision") in ("BUY", "SELL")
            and llm_decision.get("confidence", 0) >= 60
        )

        if should_trade:
            self._execute_trade(symbol, llm_decision, confluence, account)

    def _execute_trade(self, symbol: str, llm_decision: dict, confluence: dict, account: dict):
        """Calculate position size and place order."""
        direction  = llm_decision["decision"]
        sl_pips    = llm_decision.get("sl_pips", 20)
        tp_pips    = llm_decision.get("tp_pips", 40)
        balance    = account.get("balance", 10000)

        # Simple position sizing: risk % of balance
        risk_amount = balance * (RISK["risk_per_trade_pct"] / 100)
        pip_value   = 10.0  # Standard lot pip value for major pairs (USD account)
        volume      = round(risk_amount / (sl_pips * pip_value), 2)
        volume      = max(0.01, min(volume, 10.0))  # Cap between 0.01 and 10 lots

        # Get current price for SL/TP calculation
        tick = connector.get_tick(symbol)
        if not tick:
            logger.error(f"Cannot get tick for {symbol} — aborting trade")
            return

        pip_size = 0.0001 if "JPY" not in symbol else 0.01
        price    = tick["ask"] if direction == "BUY" else tick["bid"]

        if direction == "BUY":
            sl = round(price - sl_pips * pip_size, 5)
            tp = round(price + tp_pips * pip_size, 5)
        else:
            sl = round(price + sl_pips * pip_size, 5)
            tp = round(price - tp_pips * pip_size, 5)

        rr = tp_pips / sl_pips if sl_pips > 0 else 0
        if rr < RISK["min_rr_ratio"]:
            logger.info(f"{symbol}: R:R too low ({rr:.2f} < {RISK['min_rr_ratio']}) — skipping")
            return

        logger.info(
            f"PLACING {direction} | {symbol} | {volume} lots | "
            f"Entry: {price} | SL: {sl} | TP: {tp} | R:R: {rr:.2f}"
        )

        result = connector.place_order(
            symbol=symbol, direction=direction,
            volume=volume, sl=sl, tp=tp,
            comment=f"bot_{confluence.get('probability')}pct",
        )

        if result:
            tags = " | ".join([
                k for k, v in confluence.get("breakdown", {}).items()
                if v.get("signal") == direction
            ])
            excel_manager.write_trade({
                "open_time":  datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
                "symbol":     symbol,
                "direction":  direction,
                "volume":     volume,
                "entry":      price,
                "sl":         sl,
                "tp":         tp,
                "status":     "OPEN",
                "pnl":        0,
                "tags":       tags,
            })
            self.trades_today += 1
            logger.info(f"Trade logged to Excel. Total trades today: {self.trades_today}")
        else:
            logger.error(f"Order failed for {symbol}")

    # ── Shutdown ───────────────────────────────────────────────────────────────

    def shutdown(self):
        self.running = False
        connector.disconnect()
        account = connector.get_account_info()
        excel_manager.update_dashboard(account or {}, bot_status="STOPPED")
        logger.info("Bot shut down cleanly.")


# ── Entry Point ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    bot = ForexBot()
    bot.run(interval_seconds=900)   # Run every 15 minutes
