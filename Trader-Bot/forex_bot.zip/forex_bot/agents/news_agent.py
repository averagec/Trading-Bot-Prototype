"""
News Agent
- Fetches ForexFactory economic calendar
- Detects high-impact news windows
- Reads news headlines and assesses sentiment
- Blocks trading during news events
"""

import logging
import requests
from datetime import datetime, timezone, timedelta
from typing import Optional

from config import NEWS

logger = logging.getLogger(__name__)


class NewsAgent:

    def __init__(self):
        self.calendar_cache: list    = []
        self.last_fetch:     Optional[datetime] = None
        self.cache_ttl_mins: int     = 60

    # ── Calendar Fetching ──────────────────────────────────────────────────────

    def fetch_calendar(self) -> list:
        """Fetch weekly ForexFactory calendar (JSON endpoint)."""
        now = datetime.now(timezone.utc)

        # Use cache if fresh
        if (self.last_fetch and self.calendar_cache and
                (now - self.last_fetch).seconds < self.cache_ttl_mins * 60):
            return self.calendar_cache

        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            response = requests.get(NEWS["calendar_url"], headers=headers, timeout=10)
            response.raise_for_status()
            events = response.json()

            self.calendar_cache = self._parse_events(events)
            self.last_fetch     = now
            logger.info(f"Fetched {len(self.calendar_cache)} calendar events")
            return self.calendar_cache

        except Exception as e:
            logger.error(f"Calendar fetch failed: {e}")
            return self.calendar_cache  # Return stale cache on failure

    def _parse_events(self, raw_events: list) -> list:
        """Normalise raw FF calendar JSON into clean event dicts."""
        parsed = []
        for event in raw_events:
            try:
                # FF JSON format: date + time fields
                date_str = event.get("date", "")
                time_str = event.get("time", "")

                if not date_str or time_str in ("", "All Day", "Tentative"):
                    continue

                dt_str = f"{date_str} {time_str}"
                try:
                    dt = datetime.strptime(dt_str, "%m-%d-%Y %I:%M%p")
                    dt = dt.replace(tzinfo=timezone.utc)
                except ValueError:
                    continue

                impact = event.get("impact", "").strip()
                parsed.append({
                    "title":    event.get("title", "Unknown Event"),
                    "country":  event.get("country", ""),
                    "impact":   impact,
                    "time_utc": dt,
                    "forecast": event.get("forecast", ""),
                    "previous": event.get("previous", ""),
                })
            except Exception:
                continue

        return sorted(parsed, key=lambda x: x["time_utc"])

    # ── News Window Check ──────────────────────────────────────────────────────

    def is_news_window(self, symbol: Optional[str] = None) -> dict:
        """
        Check whether we are inside a no-trade news window.
        Returns dict with is_blocked bool + details of blocking event.
        """
        events = self.fetch_calendar()
        now    = datetime.now(timezone.utc)

        before = timedelta(minutes=NEWS["no_trade_before_mins"])
        after  = timedelta(minutes=NEWS["no_trade_after_mins"])
        filter_impacts = set(NEWS["impact_filter"])

        # Currencies affected by symbol
        pair_currencies = set()
        if symbol and len(symbol) >= 6:
            pair_currencies = {symbol[:3].upper(), symbol[3:6].upper()}

        for event in events:
            if event["impact"] not in filter_impacts:
                continue

            # If symbol specified, only block if currency is relevant
            if pair_currencies and event["country"].upper() not in pair_currencies:
                # Common currency code mapping
                country_to_ccy = {
                    "USD": "USD", "EUR": "EUR", "GBP": "GBP",
                    "JPY": "JPY", "AUD": "AUD", "CAD": "CAD",
                    "CHF": "CHF", "NZD": "NZD",
                }
                event_ccy = country_to_ccy.get(event["country"].upper(), event["country"].upper())
                if event_ccy not in pair_currencies:
                    continue

            window_start = event["time_utc"] - before
            window_end   = event["time_utc"] + after

            if window_start <= now <= window_end:
                mins_to_event = (event["time_utc"] - now).total_seconds() / 60
                return {
                    "is_blocked": True,
                    "event":      event["title"],
                    "impact":     event["impact"],
                    "event_time": event["time_utc"].strftime("%H:%M UTC"),
                    "mins_to_event": round(mins_to_event, 1),
                    "reason":     f"High-impact news: {event['title']} at {event['time_utc'].strftime('%H:%M UTC')}",
                }

        return {"is_blocked": False, "reason": "No high-impact news in window"}

    # ── Upcoming Events ────────────────────────────────────────────────────────

    def get_upcoming_events(self, hours_ahead: int = 4) -> list:
        """Return high-impact events in the next N hours."""
        events   = self.fetch_calendar()
        now      = datetime.now(timezone.utc)
        cutoff   = now + timedelta(hours=hours_ahead)
        impacts  = set(NEWS["impact_filter"])

        upcoming = [
            e for e in events
            if e["impact"] in impacts and now < e["time_utc"] <= cutoff
        ]
        return upcoming

    # ── News Sentiment ─────────────────────────────────────────────────────────

    def assess_sentiment(self, events_released: list) -> dict:
        """
        Basic rule-based sentiment from released news.
        Compares actual vs forecast values.
        """
        sentiments = {"USD": 0, "EUR": 0, "GBP": 0, "JPY": 0,
                      "AUD": 0, "CAD": 0, "CHF": 0, "NZD": 0}

        for event in events_released:
            country  = event.get("country", "").upper()
            actual   = event.get("actual", "")
            forecast = event.get("forecast", "")

            if not actual or not forecast or country not in sentiments:
                continue

            try:
                act_val  = float(str(actual).replace("%", "").replace("K", "000").replace("B", "e9").replace("M", "e6"))
                fore_val = float(str(forecast).replace("%", "").replace("K", "000").replace("B", "e9").replace("M", "e6"))

                if act_val > fore_val:
                    sentiments[country] += 1   # Better than expected = bullish currency
                elif act_val < fore_val:
                    sentiments[country] -= 1   # Worse than expected = bearish currency
            except ValueError:
                continue

        return sentiments

    def get_pair_news_bias(self, symbol: str) -> dict:
        """
        Return directional news bias for a given pair based on sentiment.
        E.g. EURUSD: EUR=+1, USD=-1 → BUY bias
        """
        if len(symbol) < 6:
            return {"bias": "NEUTRAL", "reason": "Invalid symbol"}

        base  = symbol[:3].upper()
        quote = symbol[3:6].upper()

        recent_events = [e for e in self.fetch_calendar()
                         if e["time_utc"] < datetime.now(timezone.utc)]
        sentiment     = self.assess_sentiment(recent_events)

        base_score  = sentiment.get(base, 0)
        quote_score = sentiment.get(quote, 0)
        diff        = base_score - quote_score

        if diff > 0:
            bias = "BUY"
        elif diff < 0:
            bias = "SELL"
        else:
            bias = "NEUTRAL"

        return {
            "bias":        bias,
            "base_score":  base_score,
            "quote_score": quote_score,
            "diff":        diff,
            "reason":      f"{base} sentiment: {base_score:+d}, {quote} sentiment: {quote_score:+d}",
        }

    def summary(self, symbol: Optional[str] = None) -> dict:
        """Full news summary for a symbol: window check + upcoming + bias."""
        window   = self.is_news_window(symbol)
        upcoming = self.get_upcoming_events()
        bias     = self.get_pair_news_bias(symbol) if symbol else {}

        return {
            "news_window":    window,
            "upcoming_count": len(upcoming),
            "upcoming":       upcoming[:3],
            "pair_bias":      bias,
        }


# Singleton
news_agent = NewsAgent()
