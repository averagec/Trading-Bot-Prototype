"""
Strategy Engine
Detects: Liquidity Sweeps, Quarterly Theory, Candle Patterns, Trend, FVGs.
Each function returns a signal dict with score contribution and metadata.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timezone
from typing import Optional


# ══════════════════════════════════════════════════════════════════════════════
# 1. LIQUIDITY SWEEPS
# ══════════════════════════════════════════════════════════════════════════════

def detect_liquidity_sweep(df: pd.DataFrame, lookback: int = 20, pip_threshold: float = 0.0005) -> dict:
    """
    Detect liquidity sweeps: price raids equal highs/lows then rejects.
    Returns signal direction and confidence.
    """
    if len(df) < lookback + 2:
        return {"signal": "NONE", "score": 0, "reason": "Insufficient data"}

    recent   = df.iloc[-lookback - 1 : -1]
    last     = df.iloc[-1]
    prev     = df.iloc[-2]

    swing_high = recent["high"].max()
    swing_low  = recent["low"].min()

    swept_high = (prev["high"] > swing_high) and (last["close"] < swing_high)
    swept_low  = (prev["low"]  < swing_low)  and (last["close"] > swing_low)

    if swept_high:
        wick_size = prev["high"] - max(prev["open"], prev["close"])
        body_size = abs(prev["close"] - prev["open"])
        rejection_strength = min(wick_size / (body_size + 1e-8), 3.0) / 3.0
        return {
            "signal":   "SELL",
            "score":    25,
            "reason":   f"Swept highs at {swing_high:.5f}, rejection confirmed",
            "level":    swing_high,
            "strength": round(rejection_strength, 2),
        }

    if swept_low:
        wick_size = min(prev["open"], prev["close"]) - prev["low"]
        body_size = abs(prev["close"] - prev["open"])
        rejection_strength = min(wick_size / (body_size + 1e-8), 3.0) / 3.0
        return {
            "signal":   "BUY",
            "score":    25,
            "reason":   f"Swept lows at {swing_low:.5f}, rejection confirmed",
            "level":    swing_low,
            "strength": round(rejection_strength, 2),
        }

    return {"signal": "NONE", "score": 0, "reason": "No liquidity sweep detected"}


# ══════════════════════════════════════════════════════════════════════════════
# 2. QUARTERLY THEORY (ICT)
# ══════════════════════════════════════════════════════════════════════════════

def detect_quarterly_theory(df: pd.DataFrame) -> dict:
    """
    ICT Quarterly Theory: divides trading day into 4 quarters.
    Q1 (00-06): Accumulation | Q2 (06-12): Manipulation
    Q3 (12-18): Distribution | Q4 (18-00): Continuation/Reversal

    Bias: If Q2 made a sweep → Q3 should move opposite.
    """
    now_utc = datetime.now(timezone.utc)
    hour    = now_utc.hour

    if   0  <= hour < 6:  quarter, phase = 1, "Accumulation"
    elif 6  <= hour < 12: quarter, phase = 2, "Manipulation"
    elif 12 <= hour < 18: quarter, phase = 3, "Distribution"
    else:                  quarter, phase = 4, "Continuation"

    # London open manipulation window: 07-09 UTC typically makes the sweep
    in_manipulation_window = (7 <= hour <= 9)
    in_distribution_window = (12 <= hour <= 15)

    if in_distribution_window:
        # Check if Q2 formed a sweep (high/low made in 07-09 window)
        q2_candles = df[df["time"].dt.hour.between(7, 9)] if "time" in df.columns else pd.DataFrame()

        if not q2_candles.empty:
            q2_high = q2_candles["high"].max()
            q2_low  = q2_candles["low"].min()
            last_close = df.iloc[-1]["close"]

            # Price below Q2 low → distribution likely bearish
            if last_close < q2_low:
                return {"signal": "SELL", "score": 20, "quarter": quarter,
                        "phase": phase, "reason": f"Q3 distribution below Q2 low ({q2_low:.5f})"}
            # Price above Q2 high → distribution likely bullish
            if last_close > q2_high:
                return {"signal": "BUY", "score": 20, "quarter": quarter,
                        "phase": phase, "reason": f"Q3 distribution above Q2 high ({q2_high:.5f})"}

    if in_manipulation_window:
        return {"signal": "WAIT", "score": 10, "quarter": quarter,
                "phase": phase, "reason": "In Q2 manipulation window — waiting for sweep"}

    return {"signal": "NONE", "score": 5, "quarter": quarter,
            "phase": phase, "reason": f"Q{quarter} {phase} — no directional bias yet"}


# ══════════════════════════════════════════════════════════════════════════════
# 3. CANDLE PATTERN ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def detect_candle_pattern(df: pd.DataFrame) -> dict:
    """
    Detect high-probability candle patterns at key levels.
    Patterns: Engulfing, Pin Bar, Doji, Morning/Evening Star.
    """
    if len(df) < 3:
        return {"signal": "NONE", "score": 0, "pattern": "None"}

    c1, c2, c3 = df.iloc[-3], df.iloc[-2], df.iloc[-1]

    def body(c):     return abs(c["close"] - c["open"])
    def is_bull(c):  return c["close"] > c["open"]
    def is_bear(c):  return c["close"] < c["open"]
    def upper_wick(c): return c["high"] - max(c["open"], c["close"])
    def lower_wick(c): return min(c["open"], c["close"]) - c["low"]
    def full_range(c): return c["high"] - c["low"]

    # ── Bullish Engulfing ──────────────────────────────────────────────────
    if (is_bear(c2) and is_bull(c3) and
            c3["open"] <= c2["close"] and c3["close"] >= c2["open"]):
        return {"signal": "BUY", "score": 20, "pattern": "Bullish Engulfing",
                "reason": "Bullish engulfing candle — strong reversal signal"}

    # ── Bearish Engulfing ──────────────────────────────────────────────────
    if (is_bull(c2) and is_bear(c3) and
            c3["open"] >= c2["close"] and c3["close"] <= c2["open"]):
        return {"signal": "SELL", "score": 20, "pattern": "Bearish Engulfing",
                "reason": "Bearish engulfing candle — strong reversal signal"}

    # ── Bullish Pin Bar (Hammer) ───────────────────────────────────────────
    if (lower_wick(c3) > body(c3) * 2 and
            upper_wick(c3) < body(c3) * 0.5 and
            full_range(c3) > 0):
        return {"signal": "BUY", "score": 18, "pattern": "Bullish Pin Bar",
                "reason": "Hammer/pin bar — rejection of lower prices"}

    # ── Bearish Pin Bar (Shooting Star) ───────────────────────────────────
    if (upper_wick(c3) > body(c3) * 2 and
            lower_wick(c3) < body(c3) * 0.5 and
            full_range(c3) > 0):
        return {"signal": "SELL", "score": 18, "pattern": "Bearish Pin Bar",
                "reason": "Shooting star — rejection of higher prices"}

    # ── Morning Star ───────────────────────────────────────────────────────
    if (is_bear(c1) and body(c2) < body(c1) * 0.3 and is_bull(c3) and
            c3["close"] > (c1["open"] + c1["close"]) / 2):
        return {"signal": "BUY", "score": 20, "pattern": "Morning Star",
                "reason": "Morning star pattern — 3-candle bullish reversal"}

    # ── Evening Star ───────────────────────────────────────────────────────
    if (is_bull(c1) and body(c2) < body(c1) * 0.3 and is_bear(c3) and
            c3["close"] < (c1["open"] + c1["close"]) / 2):
        return {"signal": "SELL", "score": 20, "pattern": "Evening Star",
                "reason": "Evening star pattern — 3-candle bearish reversal"}

    # ── Doji (indecision) ──────────────────────────────────────────────────
    if body(c3) < full_range(c3) * 0.1:
        return {"signal": "NONE", "score": 5, "pattern": "Doji",
                "reason": "Doji — market indecision, wait for next candle"}

    return {"signal": "NONE", "score": 0, "pattern": "None",
            "reason": "No significant candle pattern"}


# ══════════════════════════════════════════════════════════════════════════════
# 4. TREND DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def detect_trend(df: pd.DataFrame) -> dict:
    """
    Multi-layer trend detection:
    - Structure: Higher highs / Higher lows (uptrend) or LH/LL (downtrend)
    - EMA alignment: 20 EMA vs 50 EMA vs 200 EMA
    Returns directional bias.
    """
    if len(df) < 200:
        return {"signal": "NONE", "score": 0, "trend": "Unknown", "reason": "Not enough data"}

    close = df["close"]

    ema20  = close.ewm(span=20,  adjust=False).mean()
    ema50  = close.ewm(span=50,  adjust=False).mean()
    ema200 = close.ewm(span=200, adjust=False).mean()

    e20, e50, e200 = ema20.iloc[-1], ema50.iloc[-1], ema200.iloc[-1]
    price = close.iloc[-1]

    # ── Structure analysis (swing highs/lows) ─────────────────────────────
    highs = df["high"].rolling(5).max()
    lows  = df["low"].rolling(5).min()

    hh = highs.iloc[-1] > highs.iloc[-10]   # Higher high
    hl = lows.iloc[-1]  > lows.iloc[-10]    # Higher low
    lh = highs.iloc[-1] < highs.iloc[-10]   # Lower high
    ll = lows.iloc[-1]  < lows.iloc[-10]    # Lower low

    structure_bull = hh and hl
    structure_bear = lh and ll

    # ── EMA alignment ─────────────────────────────────────────────────────
    ema_bull = price > e20 > e50 > e200
    ema_bear = price < e20 < e50 < e200

    if structure_bull and ema_bull:
        return {"signal": "BUY", "score": 20, "trend": "Strong Uptrend",
                "reason": f"HH/HL structure + bullish EMA stack (price {price:.5f} > EMA200 {e200:.5f})"}

    if structure_bear and ema_bear:
        return {"signal": "SELL", "score": 20, "trend": "Strong Downtrend",
                "reason": f"LH/LL structure + bearish EMA stack (price {price:.5f} < EMA200 {e200:.5f})"}

    if structure_bull or ema_bull:
        return {"signal": "BUY", "score": 12, "trend": "Weak Uptrend",
                "reason": "Partial bullish confluence (structure or EMA, not both)"}

    if structure_bear or ema_bear:
        return {"signal": "SELL", "score": 12, "trend": "Weak Downtrend",
                "reason": "Partial bearish confluence (structure or EMA, not both)"}

    return {"signal": "NONE", "score": 5, "trend": "Ranging",
            "reason": "No clear trend — market ranging"}


# ══════════════════════════════════════════════════════════════════════════════
# 5. FAIR VALUE GAPS (FVG)
# ══════════════════════════════════════════════════════════════════════════════

def detect_fvg(df: pd.DataFrame, min_gap_pips: float = 0.0003) -> dict:
    """
    Detect Fair Value Gaps (3-candle imbalance).
    Bullish FVG: low[i] > high[i-2]  → gap between candle 1 high and candle 3 low
    Bearish FVG: high[i] < low[i-2]  → gap between candle 1 low and candle 3 high

    Also checks if current price is inside an unfilled FVG → entry opportunity.
    """
    if len(df) < 10:
        return {"signal": "NONE", "score": 0, "fvg_type": "None"}

    fvgs_bull = []
    fvgs_bear = []

    for i in range(2, len(df)):
        c1, c2, c3 = df.iloc[i-2], df.iloc[i-1], df.iloc[i]

        # Bullish FVG
        if c3["low"] > c1["high"] and (c3["low"] - c1["high"]) >= min_gap_pips:
            fvgs_bull.append({
                "top":    c3["low"],
                "bottom": c1["high"],
                "time":   c2["time"] if "time" in df.columns else i,
            })

        # Bearish FVG
        if c3["high"] < c1["low"] and (c1["low"] - c3["high"]) >= min_gap_pips:
            fvgs_bear.append({
                "top":    c1["low"],
                "bottom": c3["high"],
                "time":   c2["time"] if "time" in df.columns else i,
            })

    price = df.iloc[-1]["close"]

    # Check if price is inside a recent bullish FVG (potential buy)
    for fvg in reversed(fvgs_bull[-5:]):
        if fvg["bottom"] <= price <= fvg["top"]:
            return {
                "signal":   "BUY",
                "score":    15,
                "fvg_type": "Bullish FVG",
                "fvg_zone": (fvg["bottom"], fvg["top"]),
                "reason":   f"Price {price:.5f} inside bullish FVG ({fvg['bottom']:.5f} – {fvg['top']:.5f})",
            }

    # Check if price is inside a recent bearish FVG (potential sell)
    for fvg in reversed(fvgs_bear[-5:]):
        if fvg["bottom"] <= price <= fvg["top"]:
            return {
                "signal":   "SELL",
                "score":    15,
                "fvg_type": "Bearish FVG",
                "fvg_zone": (fvg["bottom"], fvg["top"]),
                "reason":   f"Price {price:.5f} inside bearish FVG ({fvg['bottom']:.5f} – {fvg['top']:.5f})",
            }

    # FVGs present but price not inside one
    if fvgs_bull or fvgs_bear:
        nearest = "Bullish" if fvgs_bull else "Bearish"
        return {"signal": "NONE", "score": 5, "fvg_type": f"{nearest} FVG nearby",
                "reason": "FVGs detected but price not at zone yet",
                "bull_fvgs": len(fvgs_bull), "bear_fvgs": len(fvgs_bear)}

    return {"signal": "NONE", "score": 0, "fvg_type": "None", "reason": "No FVGs detected"}


# ══════════════════════════════════════════════════════════════════════════════
# CONFLUENCE SCORER
# ══════════════════════════════════════════════════════════════════════════════

def run_confluence(df_m15: pd.DataFrame, df_h1: pd.DataFrame, df_h4: pd.DataFrame) -> dict:
    """
    Run all strategies and combine into a single probability score.
    Returns final signal, score %, and full breakdown.
    """
    sweep    = detect_liquidity_sweep(df_m15)
    qt       = detect_quarterly_theory(df_h1)
    candle   = detect_candle_pattern(df_m15)
    trend    = detect_trend(df_h4)
    fvg      = detect_fvg(df_m15)

    signals = {
        "liquidity_sweep":  sweep,
        "quarterly_theory": qt,
        "candle_pattern":   candle,
        "trend":            trend,
        "fvg":              fvg,
    }

    # Count directional votes
    buy_score  = sum(s["score"] for s in signals.values() if s.get("signal") == "BUY")
    sell_score = sum(s["score"] for s in signals.values() if s.get("signal") == "SELL")
    max_score  = 100

    if buy_score > sell_score:
        direction    = "BUY"
        final_score  = buy_score
    elif sell_score > buy_score:
        direction    = "SELL"
        final_score  = sell_score
    else:
        direction    = "NONE"
        final_score  = 0

    probability = round((final_score / max_score) * 100, 1)

    return {
        "direction":   direction,
        "probability": probability,
        "raw_score":   final_score,
        "breakdown":   signals,
        "timestamp":   datetime.now(timezone.utc).isoformat(),
    }
